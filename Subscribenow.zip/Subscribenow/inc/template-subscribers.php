<?php
//in case the abspath has no declared exit
if( ! defined( 'ABSPATH') ) exit;
//call of the page GetSubscribers
require_once plugin_dir_path(__FILE__) . 'GetSubscribers.php';
//set the variable getSubscribers
$getSubscribers = new toaa_GetSubscribers();
//call the header of the theme
//creation of the form 
//verification of my-noncem
//set a placeholder with e-mail
//set the button with value Subscribe
//call the footer of the plugin 
get_header(); ?>

	<form action="<?php echo esc_url(admin_url('admin-post.php')) ?>" class="create-sub-form" method="POST">
		<input type="hidden" name="action" value="createsubscriber">
		<input type="hidden" name="my-noncem" value="<?php echo esc_html(wp_create_nonce('my-noncem')); ?>">
		<input type="text" name="incomingsubscriber" placeholder="e-mail">
		<button> Subscribe </button>
	</form>
	<!--<php } ?>-->


<?php get_footer(); ?>