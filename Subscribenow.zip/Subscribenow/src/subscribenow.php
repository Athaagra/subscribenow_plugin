<?php
// if define has not declared exit
if( ! defined( 'ABSPATH') ) exit;
//call the library get subscribers
require_once plugin_dir_path(__FILE__) . 'GetSubscribers.php';
//set the subscribers to the variable GetSubscribers
$getSubscribers = new toaa_GetSubscribers();
//call of the header of the theme
//Create an e-mail area call the get subscriber loop in subscriber and display them get the id in case you need to delete user
//add another form to create a POST with administrator rights to add subscribers 
get_header(); ?>

<div class="container container--narrow page-section">
  <table class="sub-adoption-table">
    <tr>
      <th>E-mail</th>
    </tr>
	<?php
	foreach($getSubscribers->subscribers as $subscriber) { ?>
    <tr>
      <td><?php echo esc_url($subscriber->email); ?></td>
      <?php if(current_user_can('administrator')) { ?>
		<td style="text-align: center;">
		<form action="<?php echo esc_url(admin_url('admin-post.php')) ?>" method="POST">
			<input type="hidden" name="action" value="deletesubscriber">
			<input type="hidden" name="idtodelete" value="<?php echo esc_url($subscriber->email); ?>">
			<button class="delete-subscriber-button"> X </button>
		</form>
	  </td>
	  <?php } ?>
	  <!--
      <td></td>
	  -->
    </tr>
	<?php } ?>
  </table>
  <?php 
	if (current_user_can('administrator')) { ?>
	<form action="<?php echo esc_url(admin_url('admin-post.php')) ?>" class="create-sub-form" method="POST">
		<input type="hidden" name="action" value="createsubscriber">
		<input type="text" name="incomingsubscriber" placeholder="e-mail">
		<button> Subscribe </button>
	</form>
	<?php } ?>
</div>
