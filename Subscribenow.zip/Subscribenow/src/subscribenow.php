<?php

if ( !defined('ABSPATH') )
 define('ABSPATH', dirname(__FILE__) . '/');
require_once( NEWDATABASETABLEPATH . 'inc/GetSubscribers.php' );
$getSubscribers = new GetSubscribers();

get_header(); ?>

<div class="container container--narrow page-section">
  <table class="sub-adoption-table">
    <tr>
      <th>E-mail</th>
    </tr>
	<?php
	foreach($getSubscribers->subscribers as $subscriber) { ?>
    <tr>
      <td><?php echo esc_hmtl($subscriber->email); ?></td>
      <?php if(current_user_can('administrator')) { ?>
		<td style="text-align: center;">
		<form action="<?php echo esc_url(admin_url('admin-post.php')) ?>" method="POST">
			<input type="hidden" name="action" value="deletesubscriber">
			<input type="hidden" name="idtodelete" value="<?php echo esc_hmtl($subscriber->email); ?>">
			<button class="delete-subscriber-button"> X </button>
		</form>
	  </td>
	  <?php } ?>
	  <!--
      <td></td>
	  -->
    </tr>
	<?php } ?>
  </table>
  <?php 
	if (current_user_can('administrator')) { ?>
	<form action="<?php echo esc_url(admin_url('admin-post.php')) ?>" class="create-sub-form" method="POST">
		<input type="hidden" name="action" value="createsubscriber">
		<input type="text" name="incomingsubscriber" placeholder="e-mail">
		<button> Subscribe </button>
	</form>
	<?php } ?>
</div>
